#!/bin/sh
if [ -n "$LD_LIBRARY_PATH" ]
then
   LD_LIBRARY_PATH=$PWD:${LD_LIBRARY_PATH}
else
   LD_LIBRARY_PATH=$PWD
fi
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH
java -jar fiatlux-server-0.2.46-all.jar ${1+"$@"} &
